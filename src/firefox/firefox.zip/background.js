try {
  importScripts(
    './scripts/events.js',
    './scripts/tabs.js',
    './scripts/utils.js',
    './scripts/alarm.js'
  );
} catch (err) {
  console.error(err.message, err.stack);
}
